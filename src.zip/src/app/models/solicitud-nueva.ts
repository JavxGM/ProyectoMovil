export interface SolicitudNueva {
    tipo?: string;
    descripcion?: string;
  }
  