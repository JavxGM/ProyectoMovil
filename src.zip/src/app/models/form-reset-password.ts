export interface FormResetPassword {
    usuario?: string;
    email?: string;
  }
  