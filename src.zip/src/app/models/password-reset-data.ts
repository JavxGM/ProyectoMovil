export interface PasswordResetData {
    oldPassword?: string;
    newPassword?: string;
    confirmPassword?: string;
  }
  