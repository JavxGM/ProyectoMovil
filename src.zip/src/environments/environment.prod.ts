export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCaYqv84GSd7vEyeVxiD8oMHbW_KJ3G0JE",
    authDomain: "proyectofinalmovil-29c0a.firebaseapp.com",
    projectId: "proyectofinalmovil-29c0a",
    storageBucket: "proyectofinalmovil-29c0a.firebasestorage.app",
    messagingSenderId: "893205006828",
    appId: "1:893205006828:web:f52cda9a3ce6bedcaf98c9",
  },
};
